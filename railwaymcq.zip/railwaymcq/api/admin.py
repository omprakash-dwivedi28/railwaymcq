from django.contrib import admin
from .models import plan,Feedback

# Register your models here.
@admin.register(plan)
class planModelAdmin(admin.ModelAdmin):
    list_display=['id','item']

@admin.register(Feedback)
class FeedbackModelAdmin(admin.ModelAdmin):
    feedback_display=['sno','zone','division','dept','date','message']

