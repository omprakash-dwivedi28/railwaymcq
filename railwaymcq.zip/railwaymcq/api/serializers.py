from rest_framework import serializers
from .models import plan,Feedback

class planSerializers(serializers.ModelSerializer):
    class Meta:
        model = plan
        fields =['id','item']


class FeedbackSerializers(serializers.ModelSerializer):
    class Meta:
        model = Feedback
        fields =['sno','zone','division','dept','date','message']



      