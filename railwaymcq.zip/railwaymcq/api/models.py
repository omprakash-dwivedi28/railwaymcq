from django.db import models

# Create your models here.
class plan (models.Model):
     item=models.CharField(max_length=500)

class Feedback(models.Model):
     sno=models.IntegerField(max_length=500)
     zone=models.CharField(max_length=10)
     division=models.CharField(max_length=10)
     dept=models.CharField(max_length=20)
     date=models.DateField(max_length=500)
     message=models.CharField(max_length=5000)
          
